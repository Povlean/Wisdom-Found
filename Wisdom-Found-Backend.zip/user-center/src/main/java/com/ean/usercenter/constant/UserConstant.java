package com.ean.usercenter.constant;

/**
 * @description:TODO
 * @author:Povlean
 */
public interface UserConstant {

    String USER_LOGIN_STATE = "userLoginState";

    // 管理员权限，默认权限
    int ADMIN_ROLE = 1;
    int DEFAULT_ROLE = 0;

}
