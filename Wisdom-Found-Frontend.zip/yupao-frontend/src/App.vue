<script setup lang="ts">
import BasicLayout from "./layouts/BasicLayout.vue";
</script>

<template>
  <div>
    <BasicLayout/>
  </div>
</template>

<style>

</style>
